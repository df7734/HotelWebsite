package com.example.hotelwebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelWebsiteApplication {

    public static void main(String[] args) {
        SpringApplication.run(HotelWebsiteApplication.class, args);
    }

}
